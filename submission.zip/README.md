# NftCollection – ERC-721 NFT Contract

## Requirements

- Node.js 18+
- Docker (for containerized tests)

## Local Setup

```bash
npm install
npx hardhat test
